import os
from PIL import Image

path_input = "images"
path_output = "images"

for name in os.listdir(path_input):
    name = ".".join(name.split(".")[:-1])
    img = Image.open(os.path.join(path_input, name+".png")).convert("RGB")
    img.save(os.path.join(path_output, name+".jpg"))
